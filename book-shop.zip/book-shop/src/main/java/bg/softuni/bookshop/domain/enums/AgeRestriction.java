package bg.softuni.bookshop.domain.enums;

public enum AgeRestriction {MINOR, TEEN, ADULT}
